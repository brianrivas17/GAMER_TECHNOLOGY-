﻿namespace GAMER_TECHNOLOGY.Data.Model
{
    public class Checkout
    {
        public string email_user { get; set; }
        public string nombre { get; set; }
        public string apellido { get; set; }
        public string direccion { get; set; }
        public string apartamento { get; set; }
        public string departamento { get; set; }
        public string ciudad { get; set; }

    }
}

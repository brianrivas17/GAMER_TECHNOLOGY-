﻿using System;

namespace GAMER_TECHNOLOGY.Data.Model
{
    public class Venta
    {
        public int id_venta { get; set; }
        public string email_user { get; set; }
        public DateTime fecha { get;set;}

    }
}

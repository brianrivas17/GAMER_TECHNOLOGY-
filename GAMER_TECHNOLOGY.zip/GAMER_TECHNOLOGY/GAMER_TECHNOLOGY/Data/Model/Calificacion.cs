﻿namespace GAMER_TECHNOLOGY.Data.Model
{
    public class Calificacion
    {
        public int id_articulo { get; set; }
        public string nombre { get; set; }
        public string comentario { get; set; }
    }
}

﻿namespace GAMER_TECHNOLOGY.Data.Model
{
    public class Devolucion
    {
        public int id_articulo { get; set; }
        public string motivo { get; set; }
        public string email_user { get; set; }
    }
}
